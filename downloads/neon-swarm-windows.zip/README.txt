Neon Swarm for Windows

Run NeonSwarm.exe to open the game in its desktop window.
The app shows a 10-second loading screen and writes startup and server logs to its console.
Microsoft Edge WebView2 Runtime is needed for the embedded game window.
If the embedded window is unavailable, the app displays a clickable local game link.
To play from other devices on your Wi-Fi, run NeonSwarm.exe --lan.
Leaderboard and game save data are stored next to NeonSwarm.exe.
