Neon Swarm for Windows

Run NeonSwarm.exe to start the game server. Your browser opens automatically.
To play from other devices on your Wi-Fi, run NeonSwarm.exe --lan.
Leaderboard and game save data are stored next to NeonSwarm.exe.
