Neon Swarm for Windows

Run NeonSwarm.exe to open the game in its desktop window.
The app checks the local server during startup, then opens the game in an embedded WebView2 window.
Install Microsoft Edge WebView2 Runtime if the embedded window cannot start.
If the embedded window is unavailable, the app displays a clickable local game link.
To play from other devices on your Wi-Fi, run NeonSwarm.exe --lan.
Leaderboard and game save data are stored next to NeonSwarm.exe.
